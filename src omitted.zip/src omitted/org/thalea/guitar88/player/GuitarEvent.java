/**
 * Aidan Thaler
 * May 19, 2019
 */

package org.thalea.guitar88.player;

/**
 * Represents a single guitar event - a note being pressed, a note
 * being released, or damper, and stores data about the event.
 */
public class GuitarEvent {
   
   /**
    * If the midi code for this
    */
   private int midiCode;
   
   /**
    * If this is a damper event, true if this is a damper on.
    */
   private boolean damperOn;
   
   /**
    * The key of the event.
    */
   private int key;
   
   /**
    * The velocity of the event.
    */
   private int vel;
   
   /**
    * The duration in seconds of the event.
    */
   private double duration;
   
   

   /**
    * Constructs a new GuitarEvent with the data.
    *
    * @param noteOn if this a NOTE_ON event, true. False for NOTE_OFF.
    * @param key the key of the event.
    * @param vel the velocity of the event.
    * @param duration the duration in seconds before the next event.
    */
   public GuitarEvent(boolean noteOn, int key, int vel, double duration) {
      this.key = key;
      this.vel = vel;
      this.midiCode = noteOn ? Midi88Converter.NOTE_ON : Midi88Converter.NOTE_OFF;
      this.duration = duration;
   }
   
   /**
    * Constructs a new GuitarEvent for a damper pedal.
    *
    * @param damperOn true if we're turning the damper on, false for off.
    */
   public GuitarEvent(boolean damperOn) {
      this.damperOn = damperOn;
      this.midiCode = Midi88Converter.DAMPER;
   }
   
   /**
    * Returns if this is a NOTE_ON event.
    *
    * @return true if this is a NOTE_ON event.
    */
   public boolean isNoteOn() {
      return this.midiCode == Midi88Converter.NOTE_ON;
   }
   
   /**
    * Returns if this is a NOTE_ON event.
    *
    * @return true if this is a NOTE_OFF event.
    */
   public boolean isNoteOff() {
      return this.midiCode == Midi88Converter.NOTE_OFF;
   }
   
   
   /**
    * Returns true if this is a damper event.
    *
    * @return true if this is a damper event.
    */
   public boolean isDamper() {
      return this.midiCode == Midi88Converter.DAMPER;
   }
   
   /**
    * Returns true if this is a damper on event.
    *
    * @return true if this is a damper on event.
    */
   public boolean isDamperOn() {
      return this.damperOn;
   }
   
   
   
   /**
    * Returns the key of this event.
    *
    * @return the key of this event.
    */
   public int key() {
      return key;
   }
   
   /**
    * Returns the velocity of this event.
    *
    * @return the velocity of this event.
    */
   public int vel() {
      return vel;
   }
   
   /**
    * Returns the duration of this event in seconds.
    *
    * @return the duration of this event in seconds.
    */
   public double duration() {
      return duration;
   }
   
   /**
    * Sets the duration of the event to the duration.
    *
    * @param duration the duration to set this to, in seconds.
    */
   public void setDuration(double duration) {
      this.duration = duration;
   }
  
   
}