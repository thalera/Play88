/**
 * Aidan Thaler
 * May 19, 2019
 */

package org.thalea.guitar88.player;

import java.io.*;
import javax.sound.midi.*;
import java.util.*;

/**
 * Converts a midi file into a GuitarLinkedList.
 */
public class Midi88Converter {

   /**
    * Midi code for a note on event.
    */
   public static final int NOTE_ON = 0x90;
   
   /**
    * Midi code for a note off event.
    */
   public static final int NOTE_OFF = 0x80;
   
   /**
    * Midi code for a tempo change event.
    */
   public static final int TEMPO_CHANGE = 0x51;
   
   /**
    * Midi code for control change.
    */
   public static final int CONTROL_CHANGE = 0xB0;
   
   /**
    * Midi code for damper pedal
    */
   public static final int DAMPER = 0x40;
   
   /**
    * The offset value of midi keys (they start at 21).
    */
   public static final int MIDI_OFFSET = 21;
   
   /**
    * Converts the midiFile into a GuitarLinkedList and returns it.
    *
    * @param midiFile the .mid or .midi file to convert.
    * @return a GuitarLinkedList containing the midiFile's data.
    * @throws FileNotFoundException if the file doesn't exist.
    * @throws InvalidMidiDataException if the file is not a proper midi file.
    * @throws IOException if it encounters an IOException.
    */
   public GuitarLinkedList convert(File midiFile) throws InvalidMidiDataException,
                                                         FileNotFoundException, IOException {
      Sequence midiSeq = MidiSystem.getSequence(midiFile);
      int ppq = midiSeq.getResolution();
      SortedMap<Long, Double> tempos = new TreeMap<>();
      SortedMap<Long, List<GuitarEvent>> events = new TreeMap<>();
      getTemposAndEvents(tempos, events, midiSeq);
      computeDurations(ppq, tempos, events);
      GuitarLinkedList list = new GuitarLinkedList();
      for (Long tick : events.keySet()) {
         // we want any note offs to come after the note ons
         Queue<GuitarEvent> noteOffs = new LinkedList<>();
         for (GuitarEvent event : events.get(tick)) {
            if (event.isNoteOn() || event.isDamper()) {
               list.add(event);
            } else {
               noteOffs.add(event);
            }
         }
         while (noteOffs.size() > 0) {
            list.add(noteOffs.remove());
         }
      }
      return list;
   }
   
   /**
    * Goes through the midiSeq and sorts tempo changes and GuitarEvents
    * into the maps. Initializes all events to 0 duration. If tempos
    * is empty, defaults to 120.
    *
    * @param tempos a map from ticks to tempos at that tick
    * @param events a map from ticks to lists of GuitarEvents.
    * @param midiSeq the sequence to pull from.
    */
   private void getTemposAndEvents(SortedMap<Long, Double> tempos, 
                              SortedMap<Long, List<GuitarEvent>> events, 
                              Sequence midiSeq) {
      for (Track track : midiSeq.getTracks()) {
         int rVel = 64; // current running velocity for note ons with 0 velocity
         boolean[] currentOns = new boolean[88];
         for (int i = 0; i < track.size(); i++) {
            MidiEvent midEvent = track.get(i);
            MidiMessage msg = midEvent.getMessage();
            if (msg instanceof MetaMessage && 
                  ((MetaMessage) msg).getType() == TEMPO_CHANGE) {
               byte[] data = ((MetaMessage) msg).getData();
               // convert data into a double
               double tempo = (data[0] & 0xff) << 16 | (data[1] & 0xff) << 8 |
                              (data[2] & 0xff);
               // this converts the tempo into bpm
               tempo = 60 / (tempo / 1000000);
               tempos.put(midEvent.getTick(), tempo);
            } else if (msg instanceof ShortMessage) {
               ShortMessage shortMsg = (ShortMessage) msg;
               // if the key is on the keyb
               if ((shortMsg.getCommand() == NOTE_ON ||
                    shortMsg.getCommand() == NOTE_OFF) &&
                    shortMsg.getData1() >= MIDI_OFFSET &&
                    shortMsg.getData1() <= 87 + MIDI_OFFSET) {
                  // get event data
                  int key = shortMsg.getData1() - MIDI_OFFSET;
                  int cVel = shortMsg.getData2();
                  long tick = midEvent.getTick();
                  // init list
                  if (!events.containsKey(tick)) {
                     events.put(tick, new LinkedList<>());
                  }
                  // update running vel
                  if (shortMsg.getCommand() == NOTE_ON) {
                     if (cVel != 0 && !currentOns[key]) {
                        rVel = cVel;
                     }
                  }
                  // swap on/off status
                  currentOns[key] = !currentOns[key];
                  // create event and add to map
                  GuitarEvent newEvent = 
                     new GuitarEvent(currentOns[key], key, rVel, 0);
                  events.get(tick).add(newEvent);
               } else if (shortMsg.getCommand() == CONTROL_CHANGE &&
                          shortMsg.getData1() == DAMPER) { // damper pedal event
                  GuitarEvent newEvent;
                  if (shortMsg.getData2() <= 63) {
                     newEvent = new GuitarEvent(false);
                  } else {
                     newEvent = new GuitarEvent(true);
                  }
                  long tick = midEvent.getTick();
                  // init list
                  if (!events.containsKey(midEvent.getTick())) {
                     events.put(tick, new LinkedList<>());
                  }
                  if (newEvent == null) System.out.println("uh oh");
                  events.get(midEvent.getTick()).add(newEvent);
               }
            }
         }
         if (tempos.isEmpty()) { // if there's no tempos, default to 120
            tempos.put((long) 0, 120.0);
         }
      }
   }
   
   /**
    * Computes and updates the duration of each event in the events, using
    * the tempos and ppq to compute time.
    *
    * @param ppq the pulses per quarter note of the sequence.
    * @param tempos ticks to tempos in bpm.
    * @param events ticks to GuitarEvents, with the events to update.
    */
   private void computeDurations(int ppq, SortedMap<Long, Double> tempos, 
                               SortedMap<Long, List<GuitarEvent>> events) {
      double prevTime = 0;
      Iterator<Long> tempoTicksItr = tempos.keySet().iterator();
      double currTempo = tempos.get(tempoTicksItr.next());
      long nextTempoChange = -1;
      if (tempoTicksItr.hasNext()) {
         nextTempoChange = tempoTicksItr.next();
      }
      GuitarEvent prevEvent = null; // so we can hold on to the last one
      for (long tick : events.keySet()) {
         double newTime = tick * (60.0 / (currTempo * ppq));
         // we want any note offs to come after the note ons
         Queue<GuitarEvent> noteOffs = new LinkedList<>();
         for (GuitarEvent event : events.get(tick)) {
            if (event.isNoteOn() || event.isDamper()) {
               if (prevEvent != null) {
                  prevEvent.setDuration(newTime - prevTime);
                  prevTime = newTime;
               }
               prevEvent = event;
            } else {
               noteOffs.add(event);
            }
         }
         while (noteOffs.size() > 0) {
            prevEvent.setDuration(newTime - prevTime);
            prevTime = newTime;
            prevEvent = noteOffs.remove();
         }
         if (tick >= nextTempoChange && nextTempoChange != -1) {
            currTempo = tempos.get(nextTempoChange);
            if (tempoTicksItr.hasNext()) {
               nextTempoChange = tempoTicksItr.next();
            } else {
               nextTempoChange = -1;
            }
            prevTime = tick * (60.0 / (currTempo * ppq));
         }
      }
      // set last note duration
      prevEvent.setDuration(1.5);
   }
   
}