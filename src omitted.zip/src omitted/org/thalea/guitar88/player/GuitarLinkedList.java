/**
 * Aidan Thaler
 * May 19, 2019
 */

package org.thalea.guitar88.player;

import org.thalea.guitar88.std.StdAudio;

/**
 * Limited version of a linked list used to store songs for a guitar88.
 */
public class GuitarLinkedList {

   private GuitarNode front;
   
   private GuitarNode end;
   
   /**
    * Duration of the current song, in seconds.
    */
   private double duration;
   
   /**
    * Duration of the current song, in ticks.
    */
   private int ticks;
   
   /**
    * Number of elements in the list.
    */
   private int size;
   
   /**
    * Adds the event to the end of the list.
    *
    * @param event the event to add.
    */
   public void add(GuitarEvent event) {
      GuitarNode node = new GuitarNode(event);
      if (front == null) {
         front = node;
         end = node;
      } else {
         end.next = node;
         end = end.next;
      }
      duration += node.event.duration();
      ticks += (int) Math.round(node.event.duration() * StdAudio.SAMPLE_RATE);
      size++;
   }
   
   /**
    * Returns the GuitarEvent at the index.
    *
    * @param index the index to go to.
    * @return the GuitarEvent at the index.
    * @throws IllegalArgumentException if the index isn't valid.
    */
   public GuitarEvent get(int index) {
      if (index < 0 || index >= size) throw new IllegalArgumentException();
      if (index == 0) return front.event;
      if (index == size - 1) return end.event;
      GuitarNode curr = front;
      for (int i = 0; i < index; i++) {
         curr = curr.next;
      }
      return curr.event;
   }
   
   /**
    * Returns the index of the event that occurs at the duration. If there is no
    * event at the duration, returns the event nearest to but not after the
    * duration.
    *
    * @param duration the duration to go to, in seconds.
    * @return the index of the event at the duration.
    * @throws IllegalArgumentException if duration is not valid.
    */
   public int getIndex(double duration) {
      if (duration < 0 || duration > this.duration) {
         throw new IllegalArgumentException();
      }
      double currDur = 0;
      GuitarNode curr = front;
      int index = 0;
      while (curr != null && currDur + curr.event.duration() <= duration) {
         currDur += curr.event.duration();
         curr = curr.next;
         index++;
      }
      if (curr == null) return size - 1;
      return index;
   }
   
   /**
    * Returns the time of the index.
    *
    * @param index the index to get the time of.
    * @return the time of the index in seconds.
    * @throws IllegalArgumentException if index is not valid.
    */
   public double getTime(int index) {
      if (index < 0 || index >= size) throw new IllegalArgumentException();
      GuitarNode curr = front;
      double time = 0;
      for (int i = 0; i < index; i++) {
         time += curr.event.duration();
         curr = curr.next;
      }
      return time;
   }
   
   /**
    * Returns the tick of the index.
    *
    * @param index the index to get the time of.
    * @return the time of the index in seconds.
    * @throws IllegalArgumentException if index is not valid.
    */
   public int getTick(int index) {
      if (index < 0 || index >= size) throw new IllegalArgumentException();
      GuitarNode curr = front;
      int tick = 0;
      for (int i = 0; i < index; i++) {
         tick += (int) Math.round(curr.event.duration() * StdAudio.SAMPLE_RATE);
         curr = curr.next;
      }
      return tick;
   }
   
   /**
    * Returns the duration of the current song stored in seconds.
    *
    * @return the duration of the current song stored in seconds.
    */
   public double getDuration() {
      return duration;
   }
   
   /**
    * Returns the duration of the current song stored in ticks.
    *
    * @return the duration of the current song stored in ticks.
    */
   public int getDurationTicks() {
      return ticks;
   }
   
   /**
    * Returns the number of events in the list.
    *
    * @return the number of events in the list.
    */
   public int size() {
      return size;
   }
   
   /**
    * A single node in the linked list.
    */
   private class GuitarNode {

      public GuitarEvent event;
      public GuitarNode next;
      
      public GuitarNode(GuitarEvent event) {
         this.event = event;
      }
      
   }
}