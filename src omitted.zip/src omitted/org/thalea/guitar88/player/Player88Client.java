/**
 * Aidan Thaler
 * May 19, 2019
 */

package org.thalea.guitar88.player;

/**
 * Client file used to run a Player88. Displays song info and allows user
 * interaction through a GUI.
 */
public class Player88Client {
   public static void main(String[] args) throws Exception {
      Player88 player = new Player88(); 
      Player88GUI playerGUI = new Player88GUI(player, "Play88");
   }
}