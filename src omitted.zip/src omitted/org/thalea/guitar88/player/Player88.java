/**
 * Aidan Thaler
 * May 19, 2019
 */

package org.thalea.guitar88.player;

import java.io.*;
import java.util.*;

import org.thalea.guitar88.instrument.guitar.Guitar88;
import org.thalea.guitar88.instrument.piano.Piano;
import org.thalea.guitar88.instrument.organ.Organ;
import org.thalea.guitar88.instrument.Instrument;
import org.thalea.guitar88.std.StdAudio;



/**
 * Is able to play midi files. Allows the user to give it a
 * file when it is constructed, or another time. Can use different
 * instruments too.
 */
public class Player88 {

   /**
    * The converter used to convert the files!
    */
   private Midi88Converter converter;
   
   /**
    * The song file to play!
    */
   private File songFile;
   
   /**
    * The list form of the song to play!
    */
   private GuitarLinkedList songList;
   
   /**
    * Our current index in the songList!
    */
   private int songIndex;
   
   /**
    * The length of the song in seconds.
    */
   private double length;
   
   /**
    * The time elapsed in seconds
    */
   private double elapsed;
   
   /**
    * If this player is playing the song.
    */
   private boolean playing;
   
   /**
    * If this player is paused.
    */
   private boolean paused;
   
   /**
    * If we are dampered.
    */
   private boolean dampered;
   
   /**
    * Buffer full of samples to play!
    */
   private volatile double[] sampleBuffer;
   
   /**
    * Boolean to keep track whether or not we should be filling the buffer rn
    */
   private volatile boolean fillBuffer;
   
   /**
    * Thread to fill the buffer!
    */
   private BufferThread bufferThread;
   
   /**
    * The current end of the buffer!
    */
   private volatile int bufferEnd;
   
   /**
    * Keys that need to be released once we un-damper
    */
   private boolean[] damperedKeys;
   
   /**
    * If this player just skipped to a point in the song.
    */
   private boolean skipped;
   
   /**
    * How many tics were left at the time we paused.
    */
   private double pausedDuration;
   
   /**
    * Used to play songs!
    */
   private volatile Instrument instr;
   
   /**
    * The master volume!
    */
   private double volume;
   
   /**
    * Number of harmonics for instruments that use it.
    */
   private int numHarm;
   
   /**
    * Constructs a new Player88 without giving it a file to play.
    * Must be given a file before attempting to play. Sets volume
    * to half.
    */
   public Player88() {
      this.instr = new Guitar88();
      this.converter = new Midi88Converter();
      this.volume = 0.5;
      this.damperedKeys = new boolean[88];
      this.sampleBuffer = new double[0];
   }
   
   /**
    * Constructs a new Player88 set to play the songFile. Sets volume
    * to half.
    *
    * @param songFile the g88 file of the song to play.
    * @throws FileNotFoundException if the file doesn't exist.
    */
   public Player88(File songFile) throws Exception {
      this.songFile = songFile;
      this.converter = new Midi88Converter();
      this.songList = converter.convert(songFile);
      setLength();
      this.instr = new Guitar88();
      this.volume = 0.5;
   }
   
   /**
    * Changes the song file to be played to the songFile. If this is currently
    * playing, it stops. If the conversion into a playable format fails,
    * the song will not be changed.
    *
    * @param songFile the g88 file of the song to play.
    */
   public void setSong(File songFile) {
      this.fillBuffer = false;
      stop();
      File oldFile = this.songFile;
      GuitarLinkedList oldList = this.songList;
      try {
         this.songFile = songFile;
         songList = converter.convert(songFile);
         sampleBuffer = new double[songList.getDurationTicks()];
         Arrays.fill(sampleBuffer, -2);
         this.bufferEnd = 0;
         songIndex = 0;
         setLength();
         this.elapsed = 0;
         this.fillBuffer = true;
         bufferThread = new BufferThread();
         bufferThread.run();
      } catch (Exception e) {
         this.songFile = oldFile;
         songList = oldList;
         System.out.println(e);
         e.printStackTrace();
      }
   }
   
   /**
    * Returns the current song file.
    *
    * @return the current song file.
    */
   public File getSong() {
      return songFile;
   }
   
   /**
    * Plays the current song all the way through.
    */
   public void play() {
      playing = true;
      if (!skipped) {
         songIndex = 0;
         elapsed = 0;
      }
      skipped = false;
      playCurrent();
   }
   
   /**
    * Plays from the current position in the file to the end.
    */
   private void playCurrent() {
      boolean broke = false;
      playing = true;
      while (songIndex < sampleBuffer.length) {
         if (sampleBuffer[songIndex] != -2) { // in case the buffer is slow
            StdAudio.play(sampleBuffer[songIndex] * volume);
            this.songIndex++;
            this.elapsed += 1.0 / StdAudio.SAMPLE_RATE;
         }
         if (!playing || paused) {
            broke = true;
            break;
         }
      }
      if (!broke) {
         playing = false;
         elapsed = length;
      }
   }
   
   /**
    * Performs the event on the instr
    *
    * @param event the event to perform.
    */
   private void performAction(GuitarEvent event) {
      if (event.isNoteOn()) { // NOTE_ON
         instr.playNote(event.key(), event.vel(), true);
         damperedKeys[event.key()] = false;
      } else if (event.isNoteOff() && !dampered) { // NOTE_OFF
         instr.releaseNote(event.key());
      } else if (event.isNoteOff() && dampered) { // delayed NOTE_OFF
         damperedKeys[event.key()] = true;
      } else if (event.isDamper() && event.isDamperOn()) {
         this.dampered = true;
      } else { // damper off
         this.dampered = false;
         for (int i = 0; i < damperedKeys.length; i++) {
            if (damperedKeys[i]) {
               damperedKeys[i] = false;
               instr.releaseNote(i);
            }
         }
      }
      advance(event.duration());
   }
   
   /**
    * Advances the instr by the given duration.
    *
    * @param duration the duration to wait before continuing.
    */
   private void advance(double duration) {
      // ticks to advance by
      int tics = (int) Math.round(duration * StdAudio.SAMPLE_RATE);
      for (int i = 0; i < tics; i++) {
         if (!fillBuffer) {
            break;
         }
         double sample = instr.sample() * .7;
         while (sample > 1 || sample < -1) sample *= .9;
         sampleBuffer[bufferEnd] = sample;
         bufferEnd++;
         instr.tic();
      }
   }
   
   /**
    * Stops playing the song and clears the instrument.
    */
   public void stop() {
      // there is code in the advance and the play method that
      // check to see if this field is false
      this.playing = false;
      this.fillBuffer = false;
      resetInstrument();
      this.elapsed = 0;
      songIndex = 0;
   }
   
   /**
    * Pauses the song. Does nothing if not playing.
    */
   public void pause() {
      if (playing) {
         this.paused = true;
      }
   }
   
   /**
    * Unpauses the song. Does nothing if not paused.
    */
   public void unpause() {
      if (paused) {
         paused = false;
         playCurrent();
      }
   }
   
   /**
    * Skips to the time in the song. Calling the play method after
    * this one will play from the point skipped to. Sets the status
    * of this to skipping (verify by calling isSkipping).
    *
    * @param time the time to skip to, in seconds.
    * @throws IllegalArgumentException if this is playing.
    */
   public void skipTo(double time) {
      if (playing) throw new IllegalArgumentException();
      songIndex = songList.getTick(songList.getIndex(time));
      elapsed = time;
      skipped = true;
      if (!bufferThread.filled) {
         resetInstrument();
         resetBuffer();
      }
   }
   
   /**
    * Returns true if this is paused.
    *
    * @return true if this is paused.
    */
   public boolean isPaused() {
      return paused;
   }
   
   /**
    * Returns true if this is currently playing.
    *
    * @return true if this is currently playing, else false.
    */
   public boolean isPlaying() {
      return playing;
   }
   
   /**
    * Returns true if this player just skipped to a point in the song.
    *
    * @return true if this player just skipped to a point in the song.
    */
   public boolean isSkipping() {
      return skipped;
   }
   
   /**
    * Sets the volume to the value. Caps at 1. Goes down to 0.
    *
    * @param value the value to set the volume to from 0 - 1;
    */
   public void setVolume(double value) {
      if (value > 1) {
         volume = 1.0;
      } else if (value < 0) {
         volume = 0.0;
      } else {
         volume = value;
      }
   }
   
   /**
    * Resets the Instrument.
    */
   private void resetInstrument() {
      if (this.instr instanceof Piano) {
         this.instr = new Piano(numHarm);
      } else if (this.instr instanceof Guitar88) {
         this.instr = new Guitar88();
      } else if (this.instr instanceof Organ) {
         if (((Organ)this.instr).isBright()) {
            this.instr = new Organ(numHarm, true);
         } else {
            this.instr = new Organ(numHarm, false);
         }
      }
   }
   
   /**
    * Resets the buffer to the current index. Starts filling
    * again from 3 sec before the current index.
    */
   private void resetBuffer() {
      if (songList != null) {
         this.fillBuffer = false; // stop filling
         double time = this.elapsed > 3 ? this.elapsed - 3 : 0;
         bufferThread.currentIndex = songList.getIndex(time);
         bufferEnd = songList.getTick(bufferThread.currentIndex);
         this.fillBuffer = true;
         bufferThread.run();
      }
   }
   
   /**
    * Empties the buffer. Used for changing instruments.
    */
   private void emptyBuffer() {
      this.sampleBuffer = new double[this.sampleBuffer.length];
      this.bufferThread = new BufferThread();
      Arrays.fill(sampleBuffer, -2);
      this.bufferEnd = 0;
   }
   
   /**
    * Sets the current instrument to the guitar.
    * Pauses the song.
    */
   public void setGuitar() {
      this.pause();
      this.fillBuffer = false;
      emptyBuffer();
      this.instr = new Guitar88();
      resetBuffer();
   }
   
   /**
    * Sets the current instrument to the piano.
    * Pauses the song.
    *
    * @param numHarm the number of harmonics per string
    */
   public void setPiano(int numHarm) {
      this.pause();
      this.numHarm = numHarm;
      this.fillBuffer = false;
      emptyBuffer();
      this.instr = new Piano(numHarm);
      resetBuffer();
   }
   
   /**
    * Sets the current instrument to the organ.
    * Pauses the song.
    *
    * @param numHarm the number of harmonics per string
    */
   public void setOrgan(int numHarm) {
      this.pause();
      this.numHarm = numHarm;
      this.fillBuffer = false;
      emptyBuffer();
      this.instr = new Organ(numHarm, false);
      resetBuffer();
   }
   
   /**
    * Sets the current instrument to the bright organ.
    * Pauses the song.
    *
    * @param numHarm the number of harmonics per string
    */
   public void setBrightOrgan(int numHarm) {
      this.pause();
      this.numHarm = numHarm;
      this.fillBuffer = false;
      emptyBuffer();
      this.instr = new Organ(numHarm, true);
      resetBuffer();
   }

   
   /**
    * Returns the current volume.
    *
    * @return the current volume.
    */
   public double getVolume() {
      return volume;
   }
   
   /**
    * Returns the time that has elapsed since the start of the song in seconds.
    * Returns 0 if the song is not playing.
    *
    * @return the time that has elapsed since the start of the song in seconds.
    */
   public double timeElapsed() {
      return this.elapsed;
   } 
   
   /**
    * Returns the length of the current song in seconds.
    *
    * @return the length of the current song in seconds.
    */
   public double length() {
      return this.length;
   }
   
   /**
    * Set the length of the current song.
    *
    */
   private void setLength() {  
      if (this.songList != null) {
         this.length = songList.getDuration();
      }
   }
   
   /**
    * Returns the name of the currently playing song file.
    *
    * @return the name of the currently playing song.
    */
   public String getSongName() {
      return songFile.getName();
   }
   
   /**
    * Thread to fill the sample buffer while the other one plays music!
    */
   private class BufferThread extends Thread {
      
      // our current index
      public volatile int currentIndex;
      // whether this shit is completely filled
      public volatile boolean filled;
      
      public void run() {
         boolean startedFromZero = currentIndex == 0;
         long start = System.currentTimeMillis();
         while (currentIndex < songList.size() && fillBuffer) {
            performAction(songList.get(currentIndex));
            currentIndex++;
         }
         if (fillBuffer && startedFromZero) {
               filled = true;
         }
         System.err.println(System.currentTimeMillis() - start + "ms");
         System.err.println(instr);
      }
   }
   
}