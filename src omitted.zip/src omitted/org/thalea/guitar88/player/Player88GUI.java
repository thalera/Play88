/**
 * Aidan Thaler
 * May 19, 2019
 */

package org.thalea.guitar88.player;

import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.util.concurrent.TimeUnit;

/**
 * Creates a GUI showcasing a given Player88. Displays the current song name,
 * the time elapsed, the total time, and gives the user the ability to change
 * the with a button.
 */
public class Player88GUI implements ActionListener, ChangeListener {

   /**
    * The player we are showing the information of.
    */
   private Player88 player;
   
   /**
    * The main frame housing the components.
    */
   private JFrame playerFrame;
   
   /**
    * Shows the name of the current song.
    */
   private JLabel nameLabel;
   
   /**
    * Shows the elapsed time.
    */
   private JLabel elapsedLabel;
   
   /**
    * Shows the total time.
    */
   private JLabel totalLabel;
   
   /**
    * Slider showing song progress
    */
   private JSlider timeSlider;
   
   /**
    * True if the user just changed the value of the time slider.
    */
   private boolean changedTime;
   
   /**
    * Slider showing volume progress
    */
   private JSlider volumeSlider;
   
   /**
    * True if the user just changed the value of the volume slider.
    */
   private boolean changedVolume;
   
   /**
    * Slider showing number of harmonics options
    */
   private JSlider harmonicsSlider;
   
   /**
    * Instrument selector.
    */
   private JComboBox instrSwitcher;
   
   /**
    * True if the user just changed the value of the harmonics slider.
    */
   private boolean changedHarm;
      
   /**
    * The play/pause button.
    */
   private JButton playButton;
   
   /**
    * The directory last opened by the user.
    */
   private String midiFileDirectory;
   
   
   /**
    * Constructs a new Player88GUI for the player.
    *
    * @param player the player to show information of.
    * @param name the name of the program to be shown to the user.
    */
   public Player88GUI(Player88 player, String name) {
      this.player = player;
      try {
         UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
      } catch (Exception e) {
         System.err.println(e);
      }
      this.playerFrame = createFrame(name, 400, 140);
      this.playerFrame.add(createContentPane());
      Timer updater = new Timer(60, this);
      updater.setActionCommand("updater");
      updater.start();
      this.playerFrame.pack();
      this.playerFrame.setVisible(true);
      midiFileDirectory = ".";
   }
   
   /**
    * Creates a new frame to house the components of the GUI.
    *
    * @param name the name of the frame to be displayed.
    * @param width the width of the frame.
    * @param height the height of the frame.
    * @return the frame.
    */
   private JFrame createFrame(String name, int width, int height) {
      JFrame frame = new JFrame(name);
      frame.setSize(width, height);
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      Dimension scrDim = Toolkit.getDefaultToolkit().getScreenSize();
      frame.setLocation(scrDim.width / 2 - frame.getSize().width / 2,
                          scrDim.height / 2 - frame.getSize().width / 2);
      frame.setResizable(false);
      return frame;
   }
   
   /**
    * Returns a new content pane with a name label, time label, and change
    * song button. Initializes the nameLabel and the timeLabel fields.
    *
    * @return a new content pane with song information.
    */
   private JPanel createContentPane() {
      JPanel contentPane = new JPanel();
      contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.PAGE_AXIS));
      contentPane.add(Box.createRigidArea(new Dimension(0 , 7)));
      this.nameLabel = addLabel(contentPane, "Song: ---");
      contentPane.add(Box.createRigidArea(new Dimension(0 , 10)));
      addTiming(contentPane);
      contentPane.add(Box.createRigidArea(new Dimension(0 , 10)));
      addInstrumentSwitcher(contentPane);
      contentPane.add(Box.createRigidArea(new Dimension(0 , 10)));
      addButtonsAndVolume(contentPane);
      contentPane.setPreferredSize(new Dimension(400, 140));
      return contentPane;
   }
   
   /**
    * Adds all the necessary timing components to the contentPane. Initializes
    * timing-related fields.
    *
    * @param contentPane the panel to add the components to.
    */
   private void addTiming(JPanel contentPane) {
      Box b = Box.createHorizontalBox();
      b.add(Box.createRigidArea(new Dimension(5, 5)));
      elapsedLabel = addLabel(b, "-:--");
      b.add(Box.createRigidArea(new Dimension(5, 5)));
      timeSlider = new JSlider(0, 10000, 0);
      timeSlider.setFocusable(false);
      timeSlider.addChangeListener(this);
      timeSlider.setEnabled(false);
      b.add(timeSlider);
      b.add(Box.createRigidArea(new Dimension(5, 5)));
      totalLabel = addLabel(b, "-:--");
      b.add(Box.createRigidArea(new Dimension(5, 5)));
      contentPane.add(b);
   }
   
   /**
    * Adds a centered label to the contentPane with the text. Returns the label.
    *
    * @param comp the component to add the label to.
    * @param text the text for the label.
    * @return the created label.
    */
   private JLabel addLabel(JComponent comp, String text) {
      JLabel label = new JLabel();
      label.setAlignmentX(Component.CENTER_ALIGNMENT);
      label.setText(text);
      comp.add(label);
      return label;
   }
   
   /**
    * Adds the instrument changer to the contentPane and the
    * harmonics slider.
    *
    * @param contentPane the panel to add the switcher
    */
   private void addInstrumentSwitcher(JPanel contentPane) {
      Box b = Box.createHorizontalBox();
      b.add(Box.createRigidArea(new Dimension(7, 5)));
      String[] instruments = {"Guitar", "Piano", "Organ", "Bright Organ"};
      instrSwitcher = new JComboBox(instruments);
      instrSwitcher.setSelectedIndex(0);
      instrSwitcher.addActionListener(this);
      instrSwitcher.setActionCommand("changeInstr");
      Dimension size = new Dimension(100, 22);
      instrSwitcher.setMaximumSize(size);
      instrSwitcher.setMinimumSize(size);
      instrSwitcher.setPreferredSize(size);
      b.add(instrSwitcher);
      b.add(Box.createRigidArea(new Dimension(20, 5)));
      b.add(new JLabel("Harmonics:"));
      b.add(Box.createRigidArea(new Dimension(5, 5)));
      harmonicsSlider = new JSlider(1, 21);
      harmonicsSlider.setFocusable(false);
      harmonicsSlider.setMajorTickSpacing(5);
      harmonicsSlider.setMinorTickSpacing(1);
      harmonicsSlider.setPaintTicks(true);
      harmonicsSlider.addChangeListener(this);
      b.add(harmonicsSlider);
      b.add(Box.createRigidArea(new Dimension(7, 5)));
      contentPane.add(b);
   }
   
   /**
    * Adds the change song button and play song button to the contentPane.
    * Adds them inside a horizontal box, side by side. Initializes the
    * playButton field.
    *
    * @param contentPane the panel to add the buttons to
    */
   private void addButtonsAndVolume(JPanel contentPane) {
      Box b = Box.createHorizontalBox();
      b.add(Box.createRigidArea(new Dimension(7, 5)));
      this.playButton = addPlaySongButton(b);
      b.add(Box.createRigidArea(new Dimension(20, 5)));
      addChangeSongButton(b);
      b.add(Box.createRigidArea(new Dimension(20, 5)));
      b.add(new JLabel("Volume:"));
      b.add(Box.createRigidArea(new Dimension(5, 5)));
      volumeSlider = new JSlider(0, 100);
      volumeSlider.setFocusable(false);
      volumeSlider.addChangeListener(this);
      b.add(volumeSlider);
      b.add(Box.createRigidArea(new Dimension(3, 5)));
      contentPane.add(b);
   }
   
   /**
    * Adds an enabled change song button to the b.
    *
    * @param b the box to add the button to.
    */
   private void addChangeSongButton(Box b) {
      JButton changeSongButton = new JButton("Change Song");
      changeSongButton.setAlignmentX(Component.CENTER_ALIGNMENT);
      changeSongButton.setMnemonic(KeyEvent.VK_C);
      changeSongButton.setActionCommand("change");
      changeSongButton.setEnabled(true);
      changeSongButton.addActionListener(this);
      Dimension size = new Dimension(100, 22);
      changeSongButton.setMaximumSize(size);
      changeSongButton.setMinimumSize(size);
      changeSongButton.setPreferredSize(size);
      b.add(changeSongButton);
   }
   
   /**
    * Adds an enabled play song button to the b and returns it.
    *
    * @param b the box to add the label to.
    * @return the button that was created.
    */
   private JButton addPlaySongButton(Box b) {
      JButton playSongButton = new JButton("Play");
      playSongButton.setAlignmentX(Component.CENTER_ALIGNMENT);
      playSongButton.setMnemonic(KeyEvent.VK_P);
      playSongButton.setActionCommand("play");
      playSongButton.setEnabled(true);
      playSongButton.addActionListener(this);
      Dimension size = new Dimension(80, 22);
      playSongButton.setMaximumSize(size);
      playSongButton.setMinimumSize(size);
      playSongButton.setPreferredSize(size);
      b.add(playSongButton);
      return playSongButton;
   }
   
   /**
    * Changes the song of the player using a file chooser. Opens to the
    * current working directory. If the chosen file is a midi file, converts
    * it first.
    *
    */
   public void changeSong() {
      JFileChooser chooser = new JFileChooser(midiFileDirectory);
      FileNameExtensionFilter fileFilter = new FileNameExtensionFilter(
      "MIDI Files", "mid", "midi");
      chooser.setFileFilter(fileFilter);
      chooser.setAcceptAllFileFilterUsed(false);
      chooser.setPreferredSize(new Dimension(800, 600));
      int result = chooser.showOpenDialog(playerFrame);
      if (result == JFileChooser.APPROVE_OPTION) {
         try {
            File songFile = chooser.getSelectedFile();
            player.setSong(songFile);
            midiFileDirectory = songFile.getParent();
            update();
         } catch (Exception e) {
            System.err.println(e);
         };
      }
   }
   
   /**
    * Updates the name and time to the current song info.
    * Also makes sure that the play button is displaying the correct
    * text.
    */
   private void update() {
      if (player.getSong() != null && !player.isSkipping()) {
         // update labels accordingly
         this.nameLabel.setText("Song: " + player.getSongName());
         String timeElapsed = getTimeString(player.timeElapsed());
         String totalTime = getTimeString(player.length());
         totalLabel.setText(totalTime);
         playButton.setText((player.isPaused() || !player.isPlaying()) ? "Play" : "Pause");
         // if the user just moved the slider, change the time.
         if (changedTime && !timeSlider.getValueIsAdjusting()) {
            changedTime = false;
            double newElapsed = timeSlider.getValue() / 10000.0 * player.length();
            player.stop();
            player.skipTo(newElapsed); 
         } else if (!timeSlider.getValueIsAdjusting()) {
            timeSlider.setValue((int)((player.timeElapsed() / player.length()) * 10000));
            elapsedLabel.setText(timeElapsed);
            if (player.isPlaying()) {
               timeSlider.setEnabled(true);
            } else {
               timeSlider.setEnabled(false);
            }
         }
      } else if (player.getSong() != null){
         player.play();
      }
      if (changedVolume) {
         changedVolume = false;
         player.setVolume(volumeSlider.getValue() / 100.0);
      } else {
         volumeSlider.setValue((int)(player.getVolume() * 100));
      }
      if (changedHarm && !harmonicsSlider.getValueIsAdjusting()) {
         changeInstr();
         changedHarm = false;
      }
   }
   
   /**
    * Returns a String representation of the time in the format m:ss
    *
    * @param time the time in seconds.
    * @return a String representation of the time.
    */
   private String getTimeString(double time) {
      int min = (int) (time) / 60;
      int sec = (int) (time) % 60;
      return sec < 10 ? min + ":0" + sec : min + ":"  + sec;
   }
   
   /**
    * Changes the instrument based on current settings.
    */
   private void changeInstr() {
      String instr = (String) instrSwitcher.getSelectedItem();
      if (instr.equals("Guitar")) {
         player.setGuitar();
      } else if (instr.equals("Piano")) {
         player.setPiano(harmonicsSlider.getValue());
      } else if (instr.equals("Organ")) {
         player.setOrgan(harmonicsSlider.getValue());
      } else if (instr.equals("Bright Organ")) {
         player.setBrightOrgan(harmonicsSlider.getValue());
      }
   }
   
   /**
    * Performs certain tasks depending on the e.
    *
    * @param e the ActionEvent that occured.
    */
   public void actionPerformed(ActionEvent e) {
      Thread updaterThread = new Thread(new Runnable() {
         @Override 
         public void run() {
            String cmd = e.getActionCommand();
            if (cmd.equals("change")) {
              changeSong();
            } else if (cmd.equals("updater")) {
               update();
            } else if (cmd.equals("play")) {
               try {
                  if (!player.isPlaying()) {
                     player.play();
                  } else if (!player.isPaused()) {
                     player.pause();
                  } else {
                     player.unpause();
                  }
               } catch (Exception e) {
                  System.err.println(e);
               }
            } else if (cmd.equals("changeInstr")) {
               changeInstr();
            }
         }
      });
      updaterThread.start();
   }
   
   /**
    * Listener used for sliders.
    */
   public void stateChanged(ChangeEvent e) {
      if (timeSlider.getValueIsAdjusting()) {
         changedTime = true;
      } else if (volumeSlider.getValueIsAdjusting()) {
         changedVolume = true;
      } else if (harmonicsSlider.getValueIsAdjusting()) {
         changedHarm = true;
      }
   }
   
}