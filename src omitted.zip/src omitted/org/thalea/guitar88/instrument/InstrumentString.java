package org.thalea.guitar88.instrument;

public interface InstrumentString {

   /**
    * Plucks this string with the vel, holding it if on. Fills up ring buffer
    * with random values depending on the range.
    *
    * @param vel how loud you want it 0 - 127.
    * @param on true if we're holding the key.
    */
   public void pluck(int vel, boolean on);
   
   /**
    * Progresses time forward by one tic.
    */
   public void tic();
   
   /**
    * Releases this string.
    */
   public void release();
   
   /**
    * Returns the current sample at the front of the ring buffer.
    *
    * @return the current sample at the front of the ring buffer.
    */
   public double sample();

}