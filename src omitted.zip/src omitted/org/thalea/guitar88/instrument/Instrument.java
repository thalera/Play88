package org.thalea.guitar88.instrument;

public interface Instrument {

    /**
     * Plays the note with the velocity, holds it if on.
     *
     * @param note the int value 0 - 87 of the key to play.
     * @param vel how hard to play the note from 0 - 127.
     * @param on true if we are holding the note
     */
   public void playNote(int note, int vel, boolean on);
   
   /**
     * Releases the key.
     *
     * @param note the note to release.
     */
   public void releaseNote(int note);
   
    /**
     * Returns the current sound sample.
     *
     * @return the current sound sample.
     */
   public double sample();
   
    /**
     * Progresses time forward by one tic for all notes.
     */
   public void tic();
}